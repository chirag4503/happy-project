package com.SpringBoot.Colleges;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CollegesApplicationTests {

	@Test
	void contextLoads() {
	}

}
